#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
int ret;
printf("Hello! I am exec1 with PID %d\n ",getpid());
char *args[]={"./demo4",NULL};
ret = execv(args[0],args);
if(ret<0){
printf("An error occured. Exec1 terminating\n");
}
return 0;
}
