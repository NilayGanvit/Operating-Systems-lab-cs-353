#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
printf("Hello! I am exec1 with PID %d\n ",getpid());
//char *args[]={"/usr/bin/ls",NULL};
char *args[]={"/usr/bin/brave-browser",NULL};
execvp(args[0],args);
printf("Exec1 terminating\n");
return 0;
}
