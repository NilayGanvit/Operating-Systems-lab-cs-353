#include <stdio.h>
#include <unistd.h>
/* This program forks and and the prints whether the process is
* - the child (the return value of fork() is 0), or
* - the parent (the return value of fork() is not zero)
*/
int main()
{
int pid = fork();
if ( pid == 0 )
{
printf("-------------This is being printed in the child process-------------\n" );
printf("Hello! I am child process with Process id(PID) %d and parent process id %d\n\n\n",getpid(),getppid());
}
else
{
printf("----------This is being printed in the parent process:--------------\n");
printf("Hello! I am process with PID %d\n\n\n",getpid());
}
return 0;
}
